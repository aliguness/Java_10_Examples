package com.bilgeadam.lesson023.futbol_uygulaması;

import java.util.ArrayList;
import java.util.List;

public class TeknikHeyet {
	
	private List<String> saglikPersoneli;
	private List<String> antrenorler;
	private String teknikDirektor;
	
	
	public TeknikHeyet() {
		this.saglikPersoneli = new ArrayList<>();
		this.antrenorler = new ArrayList<>();
		this.teknikDirektor = "Guardiola";
	}
	
	

}
